package et.coop.dairy

import android.content.Context
import androidx.credentials.CredentialManager
import androidx.credentials.GetCredentialRequest
import com.google.android.libraries.identity.googleid.GetSignInWithGoogleOption
import com.google.android.libraries.identity.googleid.GoogleIdTokenCredential
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.GoogleAuthProvider
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.Query
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.tasks.await

data class AppUser(
    val uid: String = "", val email: String = "", val name: String = "",
    val status: String = "pending",          // pending | approved | rejected
    val isAdmin: Boolean = false
)

data class MilkEntry(
    val date: String = "", val session: String = "Morning",
    val produced: Double = 0.0, val sold: Double = 0.0, val rejected: Double = 0.0,
    val buyer: String = "", val price: Double = 0.0, val revenue: Double = 0.0,
    val by: String = ""
)

object Repo {
    private val auth = FirebaseAuth.getInstance()
    private val db = FirebaseFirestore.getInstance()

    /** Google sign-in -> Firebase. New users get a "pending" profile that only an admin can change. */
    suspend fun signIn(context: Context) {
        val option = GetSignInWithGoogleOption.Builder(context.getString(R.string.default_web_client_id)).build()
        val request = GetCredentialRequest.Builder().addCredentialOption(option).build()
        val result = CredentialManager.create(context).getCredential(context, request)
        val google = GoogleIdTokenCredential.createFrom(result.credential.data)
        val user = auth.signInWithCredential(GoogleAuthProvider.getCredential(google.idToken, null)).await().user!!
        val ref = db.collection("users").document(user.uid)
        if (!ref.get().await().exists()) {
            ref.set(mapOf(
                "email" to (user.email ?: ""), "name" to (user.displayName ?: ""),
                "status" to "pending", "isAdmin" to false, "createdAt" to FieldValue.serverTimestamp()
            )).await()
        }
    }

    fun signOut() = auth.signOut()

    fun authUid(): Flow<String?> = callbackFlow {
        val l = FirebaseAuth.AuthStateListener { trySend(it.currentUser?.uid) }
        auth.addAuthStateListener(l); awaitClose { auth.removeAuthStateListener(l) }
    }

    fun profile(uid: String): Flow<AppUser?> = callbackFlow {
        val reg = db.collection("users").document(uid).addSnapshotListener { s, _ ->
            trySend(s?.toObject(AppUser::class.java)?.copy(uid = uid))
        }
        awaitClose { reg.remove() }
    }

    fun pendingUsers(): Flow<List<AppUser>> = callbackFlow {
        val reg = db.collection("users").whereEqualTo("status", "pending").addSnapshotListener { s, _ ->
            trySend(s?.documents?.mapNotNull { it.toObject(AppUser::class.java)?.copy(uid = it.id) } ?: emptyList())
        }
        awaitClose { reg.remove() }
    }

    suspend fun setStatus(uid: String, status: String) {
        db.collection("users").document(uid).update("status", status).await()
    }

    fun milkEntries(): Flow<List<MilkEntry>> = callbackFlow {
        val reg = db.collection("milkLogs").orderBy("date", Query.Direction.DESCENDING).limit(200)
            .addSnapshotListener { s, _ -> trySend(s?.toObjects(MilkEntry::class.java) ?: emptyList()) }
        awaitClose { reg.remove() }
    }

    suspend fun addMilk(e: MilkEntry) {
        db.collection("milkLogs").add(e.copy(by = auth.currentUser?.email ?: "")).await()
    }
}
