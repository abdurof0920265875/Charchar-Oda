# COBFCU Dairy Farm – Android app (Kotlin, Jetpack Compose, Firebase)

Google sign-in + **admin approval gate**. New users land as `pending`; only an admin can approve.
Data screens follow your workbook: Daily Milk Log -> Monthly Report indicators.

## Setup
1. Firebase console -> create project -> add Android app, package `et.coop.dairy`, add your debug/release SHA-1.
2. Authentication -> enable **Google** provider. Create **Firestore** database.
3. Download `google-services.json` -> put in `app/`.
4. Firestore -> Rules -> paste `firestore.rules` -> Publish.
5. Open this folder in Android Studio (Ladybug+), Sync, Run.
6. **First admin:** sign in once with the admin Google account. In Firestore console open
   `users/<that uid>` and set `status` = `approved`, `isAdmin` = `true`. From then on that admin
   approves everyone else inside the app (Approvals tab).

## Extending
Add the other sheets (Herd Register, Breeding/AI, Health, Feed, Sales, Actions) the same way as
`milkLogs`: one Firestore collection each, same `approved()` rule.
