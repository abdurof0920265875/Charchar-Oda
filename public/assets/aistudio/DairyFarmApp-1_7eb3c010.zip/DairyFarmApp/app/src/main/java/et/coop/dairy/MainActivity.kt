package et.coop.dairy

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MaterialTheme { Surface(Modifier.fillMaxSize()) { Root() } } }
    }
}

/** Gate: signed out -> sign-in; pending/rejected -> waiting screen; approved -> app. */
@Composable
fun Root() {
    val uid by Repo.authUid().collectAsState(initial = null)
    val u = uid
    if (u == null) { SignInScreen(); return }
    val profile by remember(u) { Repo.profile(u) }.collectAsState(initial = null)
    val p = profile
    when {
        p == null -> Box(Modifier.fillMaxSize(), Alignment.Center) { CircularProgressIndicator() }
        p.status == "approved" -> Home(p)
        else -> WaitingScreen(p)
    }
}

@Composable
fun SignInScreen() {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var error by remember { mutableStateOf<String?>(null) }
    Column(Modifier.fillMaxSize().padding(24.dp), Arrangement.Center, Alignment.CenterHorizontally) {
        Text("COBFCU Dairy Farm", style = MaterialTheme.typography.headlineMedium)
        Text("Reporting app", Modifier.padding(bottom = 24.dp))
        Button(onClick = {
            scope.launch { error = try { Repo.signIn(ctx); null } catch (e: Exception) { e.message } }
        }) { Text("Sign in with Google") }
        error?.let { Text(it, color = MaterialTheme.colorScheme.error, modifier = Modifier.padding(top = 12.dp)) }
    }
}

@Composable
fun WaitingScreen(p: AppUser) {
    val rejected = p.status == "rejected"
    Column(Modifier.fillMaxSize().padding(24.dp), Arrangement.Center, Alignment.CenterHorizontally) {
        Text(if (rejected) "Access denied" else "Waiting for admin approval",
            style = MaterialTheme.typography.headlineSmall, textAlign = TextAlign.Center)
        Text(if (rejected) "An administrator declined ${p.email}."
             else "${p.email} is registered. You'll get access automatically once an admin approves you.",
            Modifier.padding(vertical = 16.dp), textAlign = TextAlign.Center)
        OutlinedButton(onClick = { Repo.signOut() }) { Text("Sign out") }
    }
}

@Composable
fun Home(p: AppUser) {
    var tab by remember { mutableIntStateOf(0) }
    val tabs = if (p.isAdmin) listOf("Milk log", "Summary", "Approvals") else listOf("Milk log", "Summary")
    Column(Modifier.fillMaxSize().statusBarsPadding()) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp), Arrangement.SpaceBetween, Alignment.CenterVertically) {
            Text(p.name.ifBlank { p.email }, style = MaterialTheme.typography.titleMedium)
            TextButton(onClick = { Repo.signOut() }) { Text("Sign out") }
        }
        TabRow(selectedTabIndex = tab) {
            tabs.forEachIndexed { i, t -> Tab(selected = tab == i, onClick = { tab = i }, text = { Text(t) }) }
        }
        when (tab) { 0 -> MilkLogScreen(); 1 -> SummaryScreen(); else -> AdminScreen() }
    }
}

@Composable
fun AdminScreen() {
    val pending by remember { Repo.pendingUsers() }.collectAsState(initial = emptyList())
    val scope = rememberCoroutineScope()
    if (pending.isEmpty()) {
        Box(Modifier.fillMaxSize(), Alignment.Center) { Text("No pending requests") }
        return
    }
    LazyColumn(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        items(pending) { u ->
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp)) {
                    Text(u.name.ifBlank { "(no name)" }, style = MaterialTheme.typography.titleMedium)
                    Text(u.email)
                    Row(Modifier.padding(top = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(onClick = { scope.launch { Repo.setStatus(u.uid, "approved") } }) { Text("Approve") }
                        OutlinedButton(onClick = { scope.launch { Repo.setStatus(u.uid, "rejected") } }) { Text("Reject") }
                    }
                }
            }
        }
    }
}

// ---- Daily Milk Log (mirrors the "Daily Milk Log" sheet) ----
@Composable
fun MilkLogScreen() {
    val entries by remember { Repo.milkEntries() }.collectAsState(initial = emptyList())
    val scope = rememberCoroutineScope()
    var date by remember { mutableStateOf(SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())) }
    var session by remember { mutableStateOf("Morning") }
    var produced by remember { mutableStateOf("") }
    var sold by remember { mutableStateOf("") }
    var rejected by remember { mutableStateOf("") }
    var buyer by remember { mutableStateOf("") }
    var price by remember { mutableStateOf("") }

    LazyColumn(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        item {
            OutlinedTextField(date, { date = it }, label = { Text("Date (yyyy-MM-dd)") }, modifier = Modifier.fillMaxWidth())
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf("Morning", "Evening").forEach { s ->
                    FilterChip(selected = session == s, onClick = { session = s }, label = { Text(s) })
                }
            }
            OutlinedTextField(produced, { produced = it }, label = { Text("Milk produced (L)") }, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(sold, { sold = it }, label = { Text("Milk sold (L)") }, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(rejected, { rejected = it }, label = { Text("Rejected / spoiled (L)") }, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(buyer, { buyer = it }, label = { Text("Buyer / destination") }, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(price, { price = it }, label = { Text("Price (ETB/L)") }, modifier = Modifier.fillMaxWidth())
            Button(onClick = {
                val s = sold.toDoubleOrNull() ?: 0.0; val pr = price.toDoubleOrNull() ?: 0.0
                scope.launch {
                    Repo.addMilk(MilkEntry(date, session, produced.toDoubleOrNull() ?: 0.0, s,
                        rejected.toDoubleOrNull() ?: 0.0, buyer, pr, s * pr))
                    produced = ""; sold = ""; rejected = ""; buyer = ""; price = ""
                }
            }, Modifier.padding(top = 8.dp)) { Text("Save entry") }
            HorizontalDivider(Modifier.padding(vertical = 12.dp))
        }
        items(entries) { e ->
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(12.dp)) {
                    Text("${e.date} · ${e.session}", style = MaterialTheme.typography.titleSmall)
                    Text("Produced ${e.produced} L · Sold ${e.sold} L · Rejected ${e.rejected} L")
                    Text("Revenue ${"%.2f".format(e.revenue)} ETB · ${e.buyer}")
                }
            }
        }
    }
}

// ---- Monthly summary (feeds the "Monthly Report" indicators) ----
@Composable
fun SummaryScreen() {
    val entries by remember { Repo.milkEntries() }.collectAsState(initial = emptyList())
    val month = SimpleDateFormat("yyyy-MM", Locale.US).format(Date())
    val m = entries.filter { it.date.startsWith(month) }
    val produced = m.sumOf { it.produced }; val sold = m.sumOf { it.sold }
    val rejected = m.sumOf { it.rejected }; val revenue = m.sumOf { it.revenue }
    val days = m.map { it.date }.distinct().size
    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text("Monthly report — $month", style = MaterialTheme.typography.titleLarge)
        Row2("Total milk produced", "%.1f L".format(produced))
        Row2("Average milk per day", if (days > 0) "%.1f L/day".format(produced / days) else "—")
        Row2("Milk sold", "%.1f L".format(sold))
        Row2("Milk rejected / spoiled", "%.1f L".format(rejected))
        Row2("Milk sales revenue", "%.2f ETB".format(revenue))
        Row2("Average selling price", if (sold > 0) "%.2f ETB/L".format(revenue / sold) else "—")
    }
}

@Composable
fun Row2(k: String, v: String) =
    Row(Modifier.fillMaxWidth(), Arrangement.SpaceBetween) { Text(k); Text(v, style = MaterialTheme.typography.titleSmall) }
